# Đề tài về FreeRTOS (Nhóm sáng thứ 6 - Tiết 1 → 5)

## **1. Danh sách các thành viên trong nhóm:**

| STT | Tên thành viên | MSSV | SĐT | Note |
| --- | --- | --- | --- | --- |
| 1 | Nguyễn Hoài Nam | 22119200 | 0363674464 |  |
| 2 | **Nguyễn Thanh Quân** | 22119219 | 0783685086 | Thuyết trình + Nhóm trưởng |
| 3 | Trương Hoài Thương | 22119237 | 0345650797 |  |
| 4 | Đặng Vĩnh Tiến | 22119239 | 0346316851 |  |

---

## 2. Nội dung đề tài:

---

### **1. Tìm hiểu về đặc điểm, chiến lược của FreeRTOS (chạy trên ESP32)**  
⇒ Chạy bằng VSCode (PlatformIO: ArduinoFreeRTOS,ESP-IDFFreeRTOS)

---

- **1. Chiến lược? - “Priority based Algorithm”: Chiến lược dựa trên độ ưu tiên**
    
    Để bắt đầu chiến lược ta dùng lệnh:
    
    ```c
    xTaskCreate(func_1, "TASK_1", configMINIMAL_STACK_SIZE, NULL, 2, NULL);// Khoi tao Task 1
    xTaskCreate(func_2, "TASK_2", configMINIMAL_STACK_SIZE, NULL, 3, NULL);// Khoi tao Task 2
    vTaskStartScheduler(); // bat dau chien luoc => vì ESP-IDF hoặc Arduino-ESP32 tự động gọi scheduler trong quá trình khởi động hệ thống
    ```
    
    - **a. Preemptive Scheduling (Ưu tiên giành quyền điều khiển)**
        - Mặc định trên ESP32, FreeRTOS cho phép một task có độ ưu tiên cao hơn được quyền giành CPU ngay lập tức khi nó sẵn sàng.
        - Giả sử:
            - Task A (priority 1) đang chạy
            - Task B (priority 5) sẵn sàng → B sẽ ngắt A ngay lập tức để chạy
    - **b. Time Slicing (Round-Robin giữa các task cùng ưu tiên)**
        - Khi có nhiều task cùng mức ưu tiên, FreeRTOS có thể chia thời gian CPU cho chúng theo kiểu luân phiên.
        - Miễn là configUSE_TIME_SLICING == 1 (default là bật)
        
        Ví dụ : Task A: priority 3
        
        Task B: priority 3
        
        => Chúng luân phiên nhau mỗi tick (tùy thuộc vào configTICK_RATE_HZ, thường là 100Hz = 10ms)
        
        Nếu tắt time slicing, task nào chạy trước sẽ giữ CPU cho đến khi:
        
        Nó gọi vTaskDelay()
        
        Bị block (chờ semaphore, queue...)
        
        Hoặc voluntarily yield (taskYIELD())
        
    - **c. Preemptive(không độc quyền) vs Non-preemptive(độc quyền)**
        
        
        | Chế độ | Đặc điểm |
        | --- | --- |
        | Preemptive (default)  | Task cao ưu tiên có thể ngắt task đang chạy |
        | Non-preemptive | Task chỉ nhường CPU khi tự gọi vTaskDelay, vTaskYield,... |
        - Cấu hình qua configUSE_PREEMPTION = 1 (Preemptive) hoặc 0 (Non-preemptive)

---

- **2.Priority? Độc quyền/không độc quyền?**
    - Có thể cấu hình chiến lược ở 2 chế độ là độc quyền và không độc quyền.
    - **Khi ở chế độ độc quyền:**
        
        ```c
        #define configUSE_PREEMPTION                         0
        //use_Preemption: co the chiem quyen duoc => khong doc quyen => <1>
        // doc quyen => <0>
        ```
        
        - Chiến lược điều phối khi ở chế độ độc quyền là thuật toán dựa trên độ ưu tiên. nếu có cùng mức độ ưu tiên thì task nào được viết đầu tiên sẽ được chạy đầu.
            
            ```c
            #define configMAX_PRIORITIES                         ( 25 )
            ```
            
        
        - Priority level (cấp độ ưu tiên): (lowest)0<1<2<3<…<24(highest) (configMAX_PRIORITIES -1) ⇒ Số càng lớn độ ưu tiên càng cao (ngược lại với lý thuyết).
        - VD: code chạy với 5 mức độ ưu tiên
            
            ```c
            #define configMAX_PRIORITIES                         ( 5 )
            ```
            
            - Code demo:
                
                ```c
                #include <stdio.h>
                #include "freertos/FreeRTOS.h"
                #include "freertos/task.h"
                
                void func(void *param) {
                    TaskHandle_t tsk = NULL;
                    tsk = xTaskGetCurrentTaskHandle();
                
                    while (1) {
                        printf("\n%s IS RUNNING\n", pcTaskGetName(tsk));
                        vTaskDelay(pdMS_TO_TICKS(2000));  // delay 2s
                    }
                }
                
                void app_main() {
                    xTaskCreate(func, "TASK_1",  1024, NULL, 1, NULL);
                    xTaskCreate(func, "TASK_2",  1024, NULL, 2, NULL);
                    xTaskCreate(func, "TASK_3",  1024, NULL, 2, NULL);
                    xTaskCreate(func, "TASK_4",  1024, NULL, 4, NULL);
                    xTaskCreate(func, "TASK_5",  1024, NULL, 3, NULL);
                    xTaskCreate(func, "TASK_6",  1024, NULL, 5, NULL);
                    xTaskCreate(func, "TASK_7",  1024, NULL, 6, NULL);
                }
                
                ```
                
            - Kết quả demo:
                
                ![image.png](image.png)
                
        - **Lưu ý :** Nếu không có hàm vtaskdelay thì task đó sẽ chạy mãi mãi mà không nhả cpu ra cho các task khác nên đây là hàm bắt buộc.
            - Code demo:
                
                ```c
                #include <stdio.h>
                #include "freertos/FreeRTOS.h"
                #include "freertos/task.h"
                
                void func(void *param) {
                    TaskHandle_t tsk = NULL;
                    tsk = xTaskGetCurrentTaskHandle();
                
                    while (1) {
                        printf("\n%s IS RUNNING\n", pcTaskGetName(tsk));
                        
                    }
                }
                
                void app_main() {
                    xTaskCreate(func, "TASK_1", configMINIMAL_STACK_SIZE + 1024, NULL, 1, NULL);
                    xTaskCreate(func, "TASK_2", configMINIMAL_STACK_SIZE + 1024, NULL, 2, NULL);
                }
                
                ```
                
            - Kết quả demo:
                
                ![image.png](image%201.png)
                
        - 1tick = 1/100hz =10ms cấu hình trong freertosconfig.h
            
            ```c
            #define configCPU_CLOCK_HZ                           ( CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ * 1000000 )
            #define configTICK_RATE_HZ                           CONFIG_FREERTOS_HZ
            ```
            
    - **Khi ở chế độ không độc quyền:**
        - Chiến lược điều phối có thể là thuật toán dựa trên độ ưu tiên và round robin with quantum=1/tickratehz = 10ms mặc định trong freeRTOS.h
            - Ai có độ ưu tiên cao hơn chạy trước.
            - Các tasks có cùng độ ưu tiên sẽ chạy round robin với q=1/timerateHZ.
            - Demo:
                - Code demo:
                    
                    ```c
                    #include <stdio.h>
                    #include "freertos/FreeRTOS.h"
                    #include "freertos/task.h"
                    
                    void func1(void *param) {
                        TaskHandle_t tsk = NULL;
                        tsk = xTaskGetCurrentTaskHandle();
                    
                        while (1) {
                            printf("\n%s IS RUNNING\n", pcTaskGetName(tsk));
                           
                        }
                    }
                    
                    void func2(void *param) {
                        TaskHandle_t tsk = NULL;
                        tsk = xTaskGetCurrentTaskHandle();
                    
                        while (1) {
                            printf("\n%s IS RUNNING\n", pcTaskGetName(tsk));
                             vTaskDelay(pdMS_TO_TICKS(2000)); 
                        }
                    }
                    
                    void func3(void *param) {
                        TaskHandle_t tsk = NULL;
                        tsk = xTaskGetCurrentTaskHandle();
                    
                        while (1) {
                            printf("\n%s IS RUNNING\n", pcTaskGetName(tsk));
                            vTaskDelay(pdMS_TO_TICKS(2000));
                        }
                    }
                    void app_main() {
                        xTaskCreate(func1, "TASK_1", configMINIMAL_STACK_SIZE + 1024, NULL, 2, NULL);
                        xTaskCreate(func2, "TASK_2", configMINIMAL_STACK_SIZE + 1024, NULL, 2, NULL);\
                        xTaskCreate(func3, "TASK_3", configMINIMAL_STACK_SIZE + 1024, NULL, 3, NULL);
                    }
                    
                    ```
                    
                - Kết quả:
                    
                    ![image.png](image%202.png)
                    
                    ![image.png](image%203.png)
                    
        - Khi đã liệt kê xong các task sẽ có câu lệnh khởi động bộ lập lịch scheduler như không phải lúc nào cũng có khi chạy trên platform io nếu chọn framework là adruino hay espidf thì cũng sẽ không cần gọi câu lệnh vTaskStartScheduler() để thực thi việc lập lịch vì vì ESP-IDF hoặc Arduino-ESP32 tự động gọi scheduler trong quá trình khởi động hệ thống

---

- **3.Watchdog của FreeRTOS làm sao để tắt làm sao để hiểu đc khinaofd nóxasyr ra tinh chỉnh nó xảy ra**
    
    ---
    
    - **3.1 WDT timer là gì ?**
        - WDT (Watchdog Timer) hay còn gọi là **bộ định thời giám sát**, là một **tíh năng phần cứng** được tích hợp trong hầu hết các vi điều khiển (MCU) như ESP32, STM32, AVR, v.v., nhằm **phát hiện và xử lý khi hệ thống bị treo hoặc gặp lỗi**.
        - **Cách hoạt động:**
            1. Khi hệ thống khởi động, WDT bắt đầu đếm ngược.
            2. Trong chương trình, **bạn phải thường xuyên reset lại WDT**(thường gọi là “pet” hoặc “kick the dog”).
            3. Nếu chương trình bị treo, không reset được WDT đúng lúc → WDT **sẽ khởi động lại hệ thống**.
        - **Ví dụ thực tế:**
            
            Giả sử bạn một vòng lặp đọc cảm biến. Nếu cảm biến bị treo và không có dữ liệu trả về, vòng lặp kẹt mãi → chương trình không "kick" WDT → WDT reset lại chip → hệ thống khởi động lại và chạy bình thường trở lại.
            
            ```c
            platform = espressif32
            board = esp32doit-devkit-v1
            framework = espidf
            monitor_speed = 115200
            build_flags = -Iinclude
            ```
            
        - **Code:**
            
            [RTOS-WDT/VD1 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD1)
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "esp_log.h"
            #include "esp_task_wdt.h"
            #include "dht11.h"
            
            #define TAG "DHT11_WDT"
            #define DHT_PIN GPIO_NUM_4
            #define WDT_TIMEOUT_S 5
            
            void dht_task(void *param) {
                esp_task_wdt_add(NULL);  // Đăng ký task với WDT
            
                while (1) {
                    esp_task_wdt_reset();  // Reset watchdog mỗi vòng
            
                    struct dht11_reading data = DHT11_read();
            
                    if (data.status != DHT11_OK) {
                        ESP_LOGE(TAG, "Sensor read error. Simulating hang...");
            
                        while (1) {
                            vTaskDelay(pdMS_TO_TICKS(1000));
                            // Không reset watchdog nữa -> sẽ bị reset hệ thống
                        }
                    }
            
                    ESP_LOGI(TAG, "Temp: %d°C, Humidity: %d%%", data.temperature, data.humidity);
                    vTaskDelay(pdMS_TO_TICKS(2000));
                }
            }
            
            void app_main(void) {
                ESP_LOGI(TAG, "Initializing DHT11 and WDT...");
            
                DHT11_init(DHT_PIN);
            
                esp_task_wdt_config_t wdt_config = {
                    .timeout_ms = WDT_TIMEOUT_S * 1000,
                    .idle_core_mask = (1 << portNUM_PROCESSORS) - 1,
                    .trigger_panic = true
                };
                esp_task_wdt_init(&wdt_config);
            
                xTaskCreate(dht_task, "dht_task", 4096, NULL, 5, NULL);
            }
            
            ```
            
        - **Kết quả console:**
            
            ![image.png](image%204.png)
            
            - `"Sensor read error. Simulating hang..."` → treo giả lập
            - `"task_wdt: Task watchdog got triggered"` → WDT hoạt động
            - `"CPU backtrace"` → panic do WDT
            - `"rst:0x1 (POWERON_RESET)"` → chip **reset lại**
            - `"boot: ESP-IDF 5.3.1 2nd stage bootloader"` → **ESP32 khởi động lại thành công**
        - **Ý nghĩa:**
            - Hệ thống được bảo vệ khỏi việc **cảm biến treo hoặc lỗi không trả dữ liệu**.
            - Giúp đảm bảo **ESP32 tự phục hồi**thay vì chết treo vĩnh viễn.
    - **3. 2 Các API trong WDT**
        
        
        | **Hàm** | **Mô tả** |
        | --- | --- |
        | `esp_task_wdt_init(int timeout_seconds, bool panic)` | Khởi tạo WDT với thời gian timeout và tùy chọn panic khi timeout. |
        | `esp_task_wdt_deinit()` | Gỡ bỏ WDT (dừng WDT toàn cục). |
        | `esp_task_wdt_add(TaskHandle_t task)` | Đăng ký task vào hệ thống WDT. Nếu task = NULL thì đăng ký task hiện tại. |
        | `esp_task_wdt_delete(TaskHandle_t task)` | Gỡ bỏ task khỏi hệ thống WDT. |
        | `esp_task_wdt_reset()` | Reset thời gian WDT của task hiện tại. |
        | `esp_task_wdt_status(TaskHandle_t task)` | Lấy trạng thái hiện tại của task (nội bộ, hiếm dùng). |
    - **3.3 Cấu hình WDT trong freeRTOS**
        - Khi khởi tạo 1 project trên flatform io dùng famework esp-idf thì chương trình sẽ sinh ra **1 file sdkconfig.esp32dev**:
        
        ![1.png](1.png)
        
        - Bên trong file có các thông tin liên quan đến WDT như :
        
        ```c
        CONFIG_FREERTOS_TASK_WDT_TIMEOUT_S=10       # timeout 10 giây
        
        CONFIG_FREERTOS_TASK_WDT_CHECK_IDLE_TASK=y  # theo dõi cả task idle
        
        CONFIG_ESP_INT_WDT_TIMEOUT_MS=3000          # INT WDT timeout 3 giây
        
        CONFIG_ESP_TASK_WDT_PANIC=y                 # Cho phép panic nếu task treo
        ```
        
        ![2.png](2.png)
        
        ![3.png](3.png)
        
        ![4.png](4.png)
        
        - Dưới đây là **ví dụ mã code cho ESP32 với ESP-IDF (dùng FreeRTOS)** để bạn thấy hậu quả khi **không bật CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0**, nghĩa là **WDT sẽ không reset khi CPU0 bị treo**:
            - **Mô tả:**
                - **Tạo một task "treo" CPU0**bằng vòng lặp vô hạn **không có vTaskDelay()**.
                - Nếu CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0 = n, hệ thống sẽ **không bị reset** dù CPU0 bị treo.
                - Nếu bạn **bật cấu hình này (=y)**, thì hệ thống **sẽ reset sau timeout WDT**.
                - CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0=n (chỉnh trong cái file rồi ctr+s)
            - Code:
                
                [RTOS-WDT/VD2 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD2)
                
                ```c
                #include <stdio.h>
                
                #include "freertos/FreeRTOS.h"
                
                #include "freertos/task.h"
                
                #include "esp_system.h"
                
                #include "esp_log.h"
                
                static const char *TAG = "WDT_DEMO";
                
                void busy_task_cpu0(void *arg)
                
                {
                
                ESP_LOGI(TAG, "Task running on CPU0, will enter infinite loop (no delay)");
                
                while (1) {
                
                // Không có delay, không nhả CPU → Idle task không bao giờ chạy
                
                __asm__ __volatile__("nop"); // Giữ CPU bận
                
                }
                
                }
                
                void app_main(void)
                
                {
                
                // Pin task vào CPU0
                
                xTaskCreatePinnedToCore(busy_task_cpu0, "BusyTaskCPU0", 2048, NULL, 5, NULL, 0);
                
                // Task chính chạy trên CPU1 → vẫn còn responsive nếu CPU1 không bị ảnh hưởng
                
                while (1) {
                
                ESP_LOGI(TAG, "Main task running on CPU1");
                
                vTaskDelay(pdMS_TO_TICKS(1000));
                
                }
                
                }
                ```
                
            - **Giải thích:**
                
                
                | **Thành phần** | **Vai trò** |
                | --- | --- |
                | **busy_task_cpu0** | **Task chạy vô hạn trên CPU0, chiếm toàn bộ thời gian CPU** |
                | **__volatile__("nop")** | **Giữ CPU bận mà không thực hiện gì (giống real-world bug)** |
                | **Không gọi vTaskDelay()** | **→ Idle task không bao giờ được CPU chạy** |
                | **Nếu không bật CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0=y** | **→ WDT không reset** |
                | **Nếu bật** | **→ ESP32 sẽ reset sau timeout (ví dụ 5 giây)** |
            
            **Rồi chụp kết quả kêu chat kết luận:**
            
            ![image.png](image%205.png)
            
            - **Mã nguồn** tạo task chiếm dụng CPU0 bằng vòng lặp vô hạn (`while(1);`) mà **không có `vTaskDelay()`** → IDLE0 không chạy được.
            - **Cấu hình hiện tại**: `CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0 = n` (tắt theo dõi IDLE0).
            - **Kết quả log:**
                - Có cảnh báo WDT:
                    
                    ```
                    yaml
                    Sao chépChỉnh sửa
                    E task_wdt: Task watchdog got triggered.
                    E task_wdt:  - IDLE0 (CPU 0)
                    
                    ```
                    
                - Cảnh báo lặp lại định kỳ (5s), nhưng **không có reset hệ thống**.
            - **Kết luận**: Khi tắt giám sát IDLE0, CPU0 bị treo cũng không gây reset – **đúng với lý thuyết**.
    - **3.4 Các loại Watchdog trong ESP-IDF**
        
        ESP-IDF hỗ trợ ba loại Watchdog Timer (WDT) chính:
        
        - **3.4.1 Hardware Watchdog Timers**
            - Gồm 2 nhóm:
                - Main System WDT (MWDT_WDT): Dùng cho Interrupt Watchdog (IWDT) và Task Watchdog (TWDT).
                - RTC Watchdog (RTC_WDT):
                    - Theo dõi thời gian từ lúc khởi động cho đến khi main() chạy.
                    - Mặc định vô hiệu hóa sau khi app khởi động, nhưng có thể giữ lại nếu chỉnh config `CONFIG_BOOTLOADER_WDT_DISABLE_IN_USER_CODE.`
            - API chính: `rtc_wdt_feed(), rtc_wdt_disable(), wdt_hal_feed(), wdt_hal_disable().`
        - **3.4.2 Interrupt Watchdog Timer (IWDT)**
            - **Mục đích:** Phát hiện nếu ISR (Interrupt Service Routine) bị chặn quá lâu.
            - **Tình huống gây timeout:**
                - ISR chạy quá lâu hoặc bị chặn.
                - portDISABLE_INTERRUPTS() hoặc critical section kéo dài.
            - **Thông số:**
                - Dùng timer hardware MWDT_WDT ở Timer Group 1.
                - Timeout cấu hình qua CONFIG_ESP_INT_WDT_TIMEOUT_MS.
                - Mặc định bật bằng CONFIG_ESP_INT_WDT.
            - **Hành động khi timeout:**
                - Gọi panic handler (Interrupt wdt timeout on CPUx).
                - Nếu panic handler không chạy được, sẽ reset chip (stage 2 timeout).
            - **Tối ưu:**
                - ISR và critical section nên ngắn gọn, không block.
                - Nếu không tránh được, tăng timeout.
        - **3.4.3 Task Watchdog Timer (TWDT)**
            - **Mục đích:** Phát hiện task nào chạy quá lâu mà không yield.
            - **Hoạt động:**
                - Mặc định theo dõi Idle Task của mỗi CPU.
                - Có thể subcribe thêm các task hoặc user riêng biệt.
                - Dùng timer hardware MWDT_WDT ở Timer Group 0.
            - **API chính:**
                - `esp_task_wdt_init(), esp_task_wdt_add(), esp_task_wdt_reset(), esp_task_wdt_delete()`
                - `esp_task_wdt_add_user(), esp_task_wdt_reset_user(), esp_task_wdt_delete_user()`
            - **Cấu hình:**
                - `CONFIG_ESP_TASK_WDT_EN`: bật TWDT.
                - `CONFIG_ESP_TASK_WDT_TIMEOUT_S`: timeout.
                - `CONFIG_ESP_TASK_WDT_PANIC`: quyết định có reset hệ thống hay chỉ in cảnh báo.
        - **Lưu ý:** Khi debug với JTAG/OpenOCD, watchdogs sẽ bị tắt tạm thời để tránh gây reset khi dừng CPU tại breakpoint.
        - **Tổng kết sự khác biệt chính**
            
            
            | Watchdog | Mục tiêu | Timeout nếu... | Timer phần cứng | Ghi chú |
            | --- | --- | --- | --- | --- |
            | RTC_WDT | Khởi động hệ thống | App không disable/reset đúng cách | RTC | Dùng khi boot |
            | IWDT | ISR/critical section | Không có tick ISR trong thời gian quy định | MWDT Group 1 | Gây panic/reset |
            | TWDT | Task hoặc user tùy chọn | Không yield/reset trong timeout | MWDT Group 0 | Có thể chỉ cảnh báo |
            
            **Cái group 0 , group 1 là**
            
            Trong ESP-IDF (ESP32), khi nói đến Group 0 và Group 1, thông thường bạn đang nói về Watchdog Timer (WDT) thuộc Timer Group Hardware – cụ thể là TG0 (Timer Group 0) và TG1 (Timer Group 1).
            
            | Watchdog | Vai trò chính |
            | --- | --- |
            | TG0 WDT (Group 0) | Thường dùng làm Main system WDT, reset toàn bộ chip nếu hệ thống treo. |
            | TG1 WDT (Group 1) | Thường dùng cho App watchdog hoặc mục đích riêng của người dùng. |
    - **3.5 Cách xử lý khi WDT xảy ra:**
        - **Khi nào WDT xảy ra?**
            - Task bị treo (không vTaskDelay, không esp_task_wdt_reset).
            - ISR chiếm CPU quá lâu.
            - Không feed Hardware WDT.
            - Deadlock trong hệ thống.
            - Vòng lặp while(1) không delay hoặc không yield.
        - **Cách xử lý WDT**
            - **Với Task WDT (TWDT)**
                
                Tình huống ví dụ: Bạn có một task đọc cảm biến nhiệt độ trong vòng lặp while(1) mỗi 5 giây. Tuy nhiên, vì bạn quên vTaskDelay() hoặc không gọi esp_task_wdt_reset(), nên TWDT sẽ phát hiện task bị "treo" và gây reset hệ thống.
                
                - **Ví dụ sai - không reset TWDT:**
                    - Code:
                        
                        [RTOS-WDT/VD3 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD3)
                        
                        ```c
                        #include "freertos/FreeRTOS.h"
                        #include "freertos/task.h"
                        #include "esp_task_wdt.h"
                        #include "esp_log.h"
                        
                        #define TAG "WDT_EXAMPLE"
                        
                        void read_temperature() {
                            // Giả lập đọc cảm biến tốn thời gian
                            vTaskDelay(pdMS_TO_TICKS(2000));
                            ESP_LOGI(TAG, "Temperature: 25°C");
                        }
                        
                        void sensor_task(void *param) {
                            esp_task_wdt_add(NULL); // Đăng ký TWDT cho task hiện tại
                        
                            while (1) {
                                read_temperature(); // Gọi hàm xử lý tốn thời gian
                                // Không có vTaskDelay hoặc esp_task_wdt_reset
                                // -> Task sẽ bị coi là treo nếu WDT timeout
                            }
                        }
                        
                        void app_main(void) {
                            xTaskCreate(sensor_task, "sensor_task", 4096, NULL, 5, NULL);
                        }
                        
                        ```
                        
                    - Kết quả:
                        - **Ví dụ *sai***  (đạt được mục đích ban đầu) — vì **task đã đăng ký với Task Watchdog (TWDT) nhưng không gọi `esp_task_wdt_reset()` hoặc `vTaskDelay()`**, khiến **TWDT hiểu task bị treo**.
                        - Giúp quan sát được behavior khi task vi phạm deadline watchdog.
                        
                        ![image.png](image%206.png)
                        
                
                ---
                
                - **Cách xử lý đúng - reset TWDT đúng cách:**
                    - Code:
                        
                        [RTOS-WDT/VD4 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD4)
                        
                        ```c
                        #include "freertos/FreeRTOS.h"
                        #include "freertos/task.h"
                        #include "esp_task_wdt.h"
                        #include "esp_log.h"
                        
                        #define TAG "WDT_EXAMPLE"
                        
                        void read_temperature() {
                            // Giả lập cảm biến mất thời gian
                            vTaskDelay(pdMS_TO_TICKS(2000));
                            ESP_LOGI(TAG, "Temperature: 25°C");
                        }
                        
                        void sensor_task(void *param) {
                            esp_task_wdt_add(NULL); // Đăng ký TWDT cho task này
                        
                            while (1) {
                                read_temperature();         // Gọi hàm xử lý mất vài giây
                                esp_task_wdt_reset();       // Reset bộ đếm watchdog mỗi vòng lặp
                            }
                        }
                        
                        void app_main(void) {
                            xTaskCreate(sensor_task, "sensor_task", 4096, NULL, 5, NULL);
                        }
                        
                        ```
                        
                    - Kết quả
                        
                        ![image.png](image%207.png)
                        
                        - **Không có bất kỳ cảnh báo hoặc lỗi nào liên quan đến TWDT** như:
                            
                            ```
                            E (xxx) task_wdt: Task watchdog got triggered. The following tasks did not reset the watchdog in time:
                            ```
                            
                        - Thay vào đó, log hiển thị đều đặn:
                            
                            ```
                            I (N) WDT_EXAMPLE: Temperature: 25℃
                            ```
                            
                            ⇒ Các dòng log này xuất hiện **liên tục theo đúng chu kỳ**, ví dụ: mỗi 2 giây (2270ms, 4270ms, 6270ms...).Điều đó **chứng minh rằng task của đang chạy bình thường, không bị Watchdog reset**, tức là đã **reset TWDT đúng cách** bằng `esp_task_wdt_reset()`
                            
                - **Để tránh bị WDT reset khi dùng FreeRTOS:**
                    - Đăng ký task với esp_task_wdt_add()
                    - Gọi esp_task_wdt_reset() định kỳ (mỗi vòng lặp nếu có xử lý nặng)
                    - Đảm bảo task không chiếm CPU quá lâu mà không yield hoặc delay
                
                ---
                
            - **Với INT WDT (Interrupt Watchdog)**
                - **Tình huống :** Bạn có một task (hoặc ISR) thực hiện tính toán lâu hoặc vòng lặp vô hạn mà không nhường CPU, khiến ngắt bị trì hoãn hoặc CPU không thể xử lý ngắt khác. INT WDT sẽ reset.
                - **Ví dụ gây lỗi INT WDT (vòng lặp vô hạn không delay):**
                    - **Code:**
                        
                        [RTOS-WDT/VD5 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD5)
                        
                        ```c
                        #include "freertos/FreeRTOS.h"
                        
                        #include "freertos/task.h"
                        
                        #include "esp_task_wdt.h"
                        
                        #include "esp_log.h"
                        
                        void bad_task(void *param)
                        
                        {
                        
                        while (1) {
                        
                        // Mô phỏng task chiếm CPU liên tục không delay
                        
                        // Không gọi vTaskDelay, không yield => CPU bị kẹt
                        
                        for (volatile int i = 0; i < 100000000; ++i) {
                        
                        // Tính toán vô nghĩa kéo dài thời gian
                        
                        }
                        
                        }
                        
                        }
                        
                        void app_main(void)
                        
                        {
                        
                        xTaskCreate(bad_task, "bad_task", 2048, NULL, 5, NULL);
                        
                        }
                        ```
                        
                    - **Kết quả:**
                        
                        ![image.png](image%208.png)
                        
                        **Dòng output quan trọng:**
                        
                        ```notion
                        E (69270) task_wdt: Task watchdog got triggered. The following tasks/users did not reset the watchdog in time:
                        E (69270) task_wdt: - IDLE0 (CPU 0)
                        E (69270) task_wdt: Tasks currently running:
                        E (69270) task_wdt: CPU 0: bad_task
                        ```
                        
                        - `IDLE0` không reset watchdog → tức là **task chạy trên CPU0 đã chiếm CPU quá lâu**, khiến task `IDLE` không được chạy → `Watchdog` hiểu là CPU bị treo.
                        - CPU0 hiện đang chạy `bad_task` → task này có thể đang:
                            - Tính toán quá lâu mà không gọi `esp_task_wdt_reset()`.
                            - Không nhường CPU bằng `vTaskDelay()` hoặc tương đương.
                            - Hoặc thậm chí bị **vòng lặp vô hạn**.
                - **Cách xử lý đúng – không để INT WDT bị kích hoạt:**
                    - **Code:**
                        
                        [RTOS-WDT/VD6 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD6)
                        
                        ```c
                        #include "freertos/FreeRTOS.h"
                        
                        #include "freertos/task.h"
                        
                        #include "esp_task_wdt.h"
                        
                        #include "esp_log.
                        
                        void good_task(void *param)
                        
                        {
                        
                        while (1) {
                        
                        // Thay vì vòng lặp lâu, ta chia nhỏ hoặc delay nhẹ
                        
                        for (int i = 0; i < 100; ++i) {
                        
                        // Mỗi lần lặp làm việc nhỏ
                        
                        vTaskDelay(pdMS_TO_TICKS(10)); // Cho CPU cơ hội xử lý ngắt
                        
                        }
                        
                        }
                        
                        }
                        
                        void app_main(void)
                        
                        {
                        
                        xTaskCreate(good_task, "good_task", 2048, NULL, 5, NULL);
                        
                        }
                        ```
                        
                    - Kết quả:
                        
                        ![image.png](image%209.png)
                        
                        **Log kết thúc tại dòng:**
                        
                        ```
                        I (270) main_task: Returned from app_main()
                        ```
                        
                        ⇒ Tức là chương trình đã khởi động xong, chạy `app_main()` và không gặp lỗi nào **ngay lúc đó**.
                        
                - **Giải thích chi tiết:**
                    
                    
                    | **Thành phần** | **Vai trò** |
                    | --- | --- |
                    | **`INT WDT`** | Theo dõi CPU có xử lý ngắt kịp thời không |
                    | `vTaskDelay` | Cho CPU nghỉ, giúp xử lý các ngắt khác kịp thời |
                    | **`Vòng lặp tính toán lâu`** | Làm CPU bị chiếm, ngắt không được xử lý → INT WDT trigger |
                    | `Guru Meditation Error` | ESP32 panic do watchdog timeout |
                - **Cách xử lý:**
                    
                    
                    | **Cách** | **Giải thích** |
                    | --- | --- |
                    | Dùng `vTaskDelay, taskYIELD` | Nhường CPU để ngắt khác được phục vụ |
                    | Tránh while(1) không delay | Dễ làm treo CPU |
                    | Không tính toán nặng trong ISR | ISR nên thật ngắn, chuyển sang task nếu xử lý dài |
    - **3.6 C Hardware WDT (Timer Group WDT)**
        - ESP32 có 2 Timer Groups (nhóm 0 và 1), mỗi nhóm có một Watchdog Timer phần cứng. Watchdog này có thể cấu hình để reset hệ thống nếu không được “gõ” (feed) đúng hạn.
            - Khác với Task WDT: theo dõi các task.
            - Khác với INT WDT: theo dõi ISR bị treo.
            - Timer Group WDT: là WDT ở cấp phần cứng, mạnh hơn, có thể cấu hình thời gian, hành động (reset CPU/system), mức interrupt, v.v.
        - **Tình huống:** Bạn muốn đảm bảo rằng hệ thống của bạn không bị treo toàn cục, ngay cả khi FreeRTOS bị lỗi hoặc task bị chết. Lúc này, bạn bật Hardware WDT để reset ESP32 nếu không được "feed" định kỳ từ app_main() hoặc timer riêng.
            - **Code: Cấu hình và dùng Timer Group WDT (TG0 hoặc TG1)**
                
                [RTOS-WDT/VD7 at main · NHN4464/RTOS-WDT](https://github.com/NHN4464/RTOS-WDT/tree/main/VD7)
                
                ```c
                #include "esp_log.h"
                #include "esp_system.h"
                #include "freertos/FreeRTOS.h"
                #include "freertos/task.h"
                #include "esp_task_wdt.h"
                
                #define TAG "TASK_WDT"
                
                void app_main(void)
                {
                    ESP_LOGI(TAG, "Cấu hình Task Watchdog Timer (TWDT)");
                
                    esp_task_wdt_config_t twdt_config = {
                        .timeout_ms = 3000,        // Timeout 3 giây
                        .idle_core_mask = BIT(0),  // Theo dõi core 0 (core chạy main task)
                        .trigger_panic = true      // Panic nếu bị timeout
                    };
                
                    esp_err_t err = esp_task_wdt_init(&twdt_config);
                    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
                        ESP_LOGE(TAG, "Không thể init TWDT: %s", esp_err_to_name(err));
                        return;
                    }
                
                    err = esp_task_wdt_add(NULL); // NULL = current task (app_main)
                    if (err != ESP_OK) {
                        ESP_LOGE(TAG, "Không thể thêm task vào TWDT: %s", esp_err_to_name(err));
                        return;
                    }
                
                    ESP_LOGI(TAG, "Bắt đầu vòng lặp - sẽ feed WDT mỗi 2 giây");
                
                    while (1) {
                        ESP_LOGI(TAG, ">> Feed WDT");
                        esp_task_wdt_reset(); // hoặc esp_task_wdt_feed();
                        vTaskDelay(pdMS_TO_TICKS(2000)); // dưới 3 giây
                    }
                }
                
                ```
                
                ![image.png](image%2010.png)
                
        - Cách xử lý **Hardware WDT (Timer Group WDT)**
            
            
            | **Thành phần** | **Vai trò** |
            | --- | --- |
            | `timer_wdt_init()` | Cấu hình phần cứng WDT cho timer group |
            | `timer_group_feed_wdt()` | “Gõ” watchdog – bắt buộc gọi định kỳ |
            | `TIMER_WDT_STAGE_ACTION_RESET_SYSTEM` | Nếu timeout → reset toàn hệ thống |
            | `vTaskDelay()` | Giả lập hệ thống vẫn đang chạy bình thường |

---

- **4.Ideal task**
    
    ---
    
    - **4.1 Tổng quan về Idle Task trong FreeRTOS**
        
        Idle Task là một tác vụ đặc biệt do FreeRTOS tự động tạo khi gọi `vTaskStartScheduler()`. Nó có vai trò đảm bảo hệ thống luôn có ít nhất một tác vụ sẵn sàng chạy, giúp kernel hoạt động ổn định.
        
    
    ---
    
    - **4.2 Đặc điểm chính**
        - Tự động tạo, không cần lập trình thủ công.
            
            ![image.png](image%2011.png)
            
            ### 1. Dòng sau cho biết: **`main` task đã kết thúc hoặc bị treo**:
            
            ```
            E (5261) task_wdt:  - main (CPU 0
            ```
            
            → Vậy **không còn task nào có thể chạy trên CPU 0** — nếu hệ thống vẫn tiếp tục hoạt động thì **chắc chắn phải có một task khác đang chạy: đó là Idle Task.**
            
            ---
            
            ### 2. Dòng sau chứng minh rằng **Idle Task đang chạy trên cả 2 core**:
            
            ```
            E (5261) task_wdt: Tasks currently running:
            E (5261) task_wdt: CPU 0: IDLE0
            E (5261) task_wdt: CPU 1: IDLE1
            ```
            
            → `IDLE0` và `IDLE1` là **hai bản sao của Idle Task chạy trên core 0 và core 1** tương ứng.
            
            ---
            
            ### 3. Dù `main()` task không gọi bất kỳ `xTaskCreate()` nào, log vẫn cho thấy:
            
            ```c
            CPU 0: IDLE0
            CPU 1: IDLE1
            ```
            
            → Tức là **FreeRTOS đã tự động tạo ra Idle Task mà bạn không lập trình gì cả**. 
            
            > "Idle Task được tạo tự động."
            > 
        - Ưu tiên thấp nhất (tskIDLE_PRIORITY), chỉ chạy khi không có tác vụ nào khác cần CPU.
            
            ![image.png](image%2012.png)
            
            - Task liên tục được **scheduler chọn chạy đều đặn mỗi 100ms**, không bị chặn, không bị preempt.
            - Điều đó xảy ra vì **không có task nào khác có mức ưu tiên cao hơn đang cần CPU** → Task ở ưu tiên thấp nhất vẫn được thực thi.
            
            ---
            
            ✔️ **Chứng minh đúng**:
            
            > "Task có ưu tiên thấp nhất (tskIDLE_PRIORITY) vẫn được scheduler cho chạy khi hệ thống rảnh → giống behavior của Idle Task."
            > 
        - Không bao giờ bị block, luôn sẵn sàng chạy khi CPU rảnh.
    
    ---
    
    - **4.3 Chức năng chính của Idle Task**
        - Dọn dẹp bộ nhớ: Khi gọi vTaskDelete(), bộ nhớ của tác vụ bị xóa sẽ chỉ được giải phóng bởi Idle Task. Nếu Idle Task không được chạy → rò rỉ bộ nhớ.
        - Chạy tác vụ nền & tiết kiệm năng lượng. Người dùng có thể tận dụng Idle Task Hook để thực hiện các công việc nền như:
            - Gửi hệ thống vào chế độ tiết kiệm năng lượng.
            - Kiểm tra tình trạng hệ thống.
            - Đo thời gian CPU rảnh
            Idle Task càng chạy nhiều → hệ thống càng rảnh. Dùng để đánh giá hiệu suất hoặc mức độ tải của hệ thống.

---

- **5.Semaphore**
    - Semaphore có thể được coi là token hoặc flag được sử dụng để đồng bộ hóa hành vi ứng dụng.
    
    ```c
    // Thu vien dung cho Semaphore
    #include "semphr.h"
    ```
    
    - **5.1 Khái niệm về Semaphore**
        - Semaphore là công cụ cơ bản dùng để **đồng bộ hóa** và **quản lý tài nguyên dùng chung**.
        - Về mặt khái niệm, Semaphore là một biến số được bảo vệ (không thể bị truy cập gián đoạn) dùng để kiểm soát sự truy cập của nhiều tác vụ (tasks) vào một tài nguyên chung. Trong FreeRTOS, chúng ta không thao tác trực tiếp với biến số này mà thông qua một bộ các hàm API. Hai hành động cơ bản trên một semaphore là **"Take"** (lấy) và **"Give"** (trả lại/cho đi).
            - **Take (Lấy Semaphore)**: Một tác vụ cố gắng "lấy" semaphore.
                - Nếu semaphore có sẵn, tác vụ sẽ lấy thành công và tiếp tục thực thi. Hành động này thường làm giảm "số lượng" của semaphore.
                - Nếu semaphore không có sẵn, tác vụ sẽ được đưa vào trạng thái **Blocked (Bị khóa)** và chờ cho đến khi semaphore có sẵn (hoặc cho đến khi hết thời gian chờ - timeout).
            - **Give (Trả Semaphore)**: Một tác vụ hoặc một trình phục vụ ngắt (ISR) "trả lại" semaphore, làm cho nó trở nên có sẵn. Hành động này thường làm tăng "số lượng" của semaphore. Nếu có một tác vụ nào đó đang bị block để chờ semaphore này, nó sẽ được "đánh thức" và chuyển sang trạng thái Ready (Sẵn sàng).
        - FreeRTOS cung cấp nhiều loại semaphore khác nhau, mỗi loại được tối ưu cho một mục đích sử dụng cụ thể.
    - **5.2 Các loại Semaphore trong FreeRTOS**
        
        FreeRTOS chia semaphore thành các loại chính sau:
        
        - **5.2.1 Binary Semaphore (Semaphore Nhị phân)**
            
            <aside>
            🔗
            
            **Link Binary Semaphore:** 
            
            [RTOS---DEMO/semaphore at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/semaphore)
            
            [[FreeRTOS_ESP32]semaphore binary](https://youtu.be/zOHsQwscARg?si=Tlps5VjAzGD0d_60)
            
            </aside>
            
            - **Khái niệm**: Bạn có thể hình dung Binary Semaphore như một hàng đợi (queue) chỉ có thể chứa tối đa **một** mục. Nó chỉ có hai trạng thái: có sẵn (đầy) hoặc không có sẵn (rỗng).
            - **Mục đích chính**: **Đồng bộ hóa (Synchronization)**. Đặc biệt hữu ích trong việc đồng bộ hóa một tác vụ với một trình phục vụ ngắt (ISR).
            - **Cơ chế hoạt động điển hình**:
                1. Một tác vụ xử lý ("handler task") gọi hàm `xSemaphoreTake()` để chờ một sự kiện. Vì semaphore ban đầu rỗng, tác vụ này sẽ ngay lập tức bị block.
                2. Khi một sự kiện phần cứng xảy ra (ví dụ: nhận được dữ liệu từ UART), ISR tương ứng sẽ được thực thi.
                3. Bên trong ISR, hàm `xSemaphoreGiveFromISR()` được gọi để "give" semaphore.
                4. Hành động "give" này sẽ đánh thức "handler task" đang bị block. Tác vụ này sẽ lấy được semaphore và tiếp tục thực thi để xử lý sự kiện.
            - **API chính**:
                - `xSemaphoreCreateBinary()`: Tạo một binary semaphore. Semaphore mới được tạo ra ở trạng thái rỗng (phải được "give" trước khi có thể "take").
                - `xSemaphoreTake(xSemaphore, xTicksToWait)`: Lấy semaphore.
                - `xSemaphoreGive(xSemaphore)`: Trả semaphore (từ một tác vụ).
                - `xSemaphoreGiveFromISR(xSemaphore, pxHigherPriorityTaskWoken)`: Trả semaphore (từ một ISR).
            
        - **5.2.2 Counting Semaphore (Semaphore Đếm)**
            
            <aside>
            🔗
            
            **Link Couting Semaphore:** 
            
            [RTOS---DEMO/semaphor_count at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/semaphor_count)
            
            [[FreeRTOS_ESP32]semaphore counting](https://youtu.be/yNfe__hzBT0?si=h8PdyblU9-TnhaN_)
            
            </aside>
            
            - **Khái niệm**: Giống như Binary Semaphore nhưng có thể "đếm" đến một giá trị tối đa được định nghĩa trước. Nó hoạt động như một hàng đợi có thể chứa N mục.
            - **Mục đích sử dụng**:
                1. **Đếm Sự kiện**: Khi có nhiều sự kiện có thể xảy ra trước khi chúng được xử lý. Mỗi khi một sự kiện xảy ra, ISR sẽ "give" semaphore, làm tăng bộ đếm. Tác vụ xử lý sẽ "take" semaphore mỗi khi nó xử lý xong một sự kiện, làm giảm bộ đếm. Giá trị của bộ đếm chính là số lượng sự kiện chưa được xử lý.
                2. **Quản lý Tài nguyên**: Khi có một nhóm gồm N tài nguyên giống hệt nhau (ví dụ: một pool gồm 5 kết nối cơ sở dữ liệu). Semaphore được tạo với bộ đếm ban đầu là N. Một tác vụ muốn sử dụng một tài nguyên phải "take" semaphore (làm giảm bộ đếm). Khi dùng xong, nó phải "give" semaphore (làm tăng bộ đếm). Nếu bộ đếm về 0, nghĩa là không còn tài nguyên nào trống.
            - **API chính**:
                - `xSemaphoreCreateCounting(uxMaxCount, uxInitialCount)`: Tạo một counting semaphore với giá trị đếm tối đa và giá trị đếm ban đầu.
        - **5.2.3. Mutex (Mutual Exclusion Semaphore)**
            - **Khái niệm**: Mutex là một loại binary semaphore đặc biệt được thiết kế riêng cho mục đích **bảo vệ tài nguyên dùng chung** (mutual exclusion).
            - **Mục đích chính**: Đảm bảo tại một thời điểm, chỉ có **một** tác vụ được phép truy cập vào một tài nguyên cụ thể (ví dụ: một biến toàn cục, một ngoại vi như I2C, SPI).
            - **Đặc điểm quan trọng phân biệt với Binary Semaphore**:
                1. **Ownership (Quyền sở hữu)**: Mutex có khái niệm về quyền sở hữu. Chỉ có tác vụ đã "take" thành công mutex mới có thể "give" nó trở lại.
                2. **Priority Inheritance (Thừa kế Ưu tiên)**: Đây là tính năng quan trọng nhất của mutex. Nó giúp giảm thiểu vấn đề **Priority Inversion** (nghịch đảo ưu tiên). Nếu một tác vụ A (ưu tiên cao) đang phải chờ một mutex do tác vụ B (ưu tiên thấp) nắm giữ, kernel sẽ tạm thời nâng độ ưu tiên của tác vụ B lên bằng độ ưu tiên của tác vụ A.
            - **API chính**:
                - `xSemaphoreCreateMutex()`: Tạo một mutex.
                - `xSemaphoreTake(xMutex, xTicksToWait)`
                - `xSemaphoreGive(xMutex)`
            

---

### **2. Tìm hiểu về thư viện menuconfig freeRTOS (FreeRTOSConfig.h)**

- **Setup Demo:**
    - Bước 1: Tạo Project mới trong VSCode
        1. Mở **VSCode**
        2. Vào mục **Extensions** và **cài đặt PlatformIO IDE**
        
        ![Picture12.png](Picture12.png)
        
        1. Sau khi cài đặt xong, click vào biểu tượng **PlatformIO** ở thanh bên trái
            
            ![13.png](13.png)
            
        2. Chọn **"New Project"**
        3. Trong cửa sổ tạo project:
            - Đặt tên project
            - Chọn board phù hợp (ví dụ: `esp32doit-devkit-v1`)
            - **Chọn framework: `ESP-IDF`**
            - Chọn nơi lưu project
            - Click **Finish**
                
                ![14.png](14.png)
                
        
        ⇒ Sau khi tạo, PlatformIO sẽ tự động tạo cấu trúc thư mục project.
        
    
    ---
    
    - Bước 2: Cách sử dụng menuconfig
        - Cách 1: Vào trực tiếp thông qua Terminal (không tùy chỉnh được nhiều thông số)
            
            ### Bước 1: Cài đặt PlatformIO bằng `pip`
            
            ```bash
            pip install platformio
            
            ```
            
            ---
            
            ### Bước 2: Mở `menuconfig` của ESP-IDF
            
            Tại thư mục gốc project vào trong terminal, chạy:
            
            ```bash
            pio run -t menuconfig
            ```
            
            🧭 Một cửa sổ **menu cấu hình ESP-IDF** sẽ hiện lên với giao diện điều hướng bằng bàn phím:
            
            - Dùng phím **mũi tên** để điều hướng
            - **Enter** để chọn
            - **Q** hoặc **ESC** để thoát
            
            ![image.png](image%2013.png)
            
            ---
            
            ### Bước 3: Vào menuconfig dùng các phím mũi tên để di chuyển, Enter để chọn.
            
            ![image.png](image%2014.png)
            
            ![image.png](image%2015.png)
            
            ![image.png](image%2016.png)
            
            ---
            
        - Cách 2: Sử dụng qua thư viện FreeRTOSConfig.h
            
            > ❗ Không chỉnh trực tiếp file gốc của PlatformIO! ( vì nếu chỉnh trục tiếp trong đây sẽ bị ảnh hưởng đến tất cả các file khác nếu như dùng đến FreeRTOS) ⇒ Dùng gián tiếp
            > 
            1. **Tìm file gốc `FreeRTOSConfig.h`** tại đường dẫn:
            
            ```
            C:\Users\<TENNGUOIDUNG>\.platformio\packages\framework-espidf\components\freertos\config\include\freertos
            ```
            
            1. **Copy** file `FreeRTOSConfig.h` vào thư mục `include/` của project bạn mới tạo.
            2. Có 2 lựa chọn:
                - **(A)** Copy toàn bộ nội dung file gốc để tùy chỉnh
                - **(B)** Tạo 1 file mới với nội dung tối giản như sau:
            
            ```c
            #include_next "freertos/FreeRTOSConfig.h"
            
            // Ghi đè các macro tại đây nếu muốn tùy chỉnh
            #define configUSE_IDLE_HOOK 1
            #define configCHECK_FOR_STACK_OVERFLOW 2
            
            ```
            
            ⇒File này sẽ **kế thừa** toàn bộ nội dung gốc từ ESP-IDF và chỉ ghi đè các macro bạn muốn thay đổi.
            
    
    ---
    
    - Bước 3: Cấu hình `platformio.ini`
        1. Mở file `platformio.ini`
        2. Thêm dòng sau:
        
        ```
        build_flags = -Iinclude
        ```
        
        - Giải thích:
            - `build_flags`: Cho phép thêm các tùy chọn khi biên dịch.
            - `Iinclude`: Thêm thư mục `include/` vào đường dẫn tìm kiếm file header (`.h`).
        1. Cấu hình hoàn chỉnh:
        
        ```
        platform = espressif32
        board = esp32doit-devkit-v1
        framework = espidf
        monitor_speed = 115200
        build_flags = -Iinclude
        ```
        
        ![16.png](16.png)
        
    
    ---
    

![image.png](image%2017.png)

![image.png](image%2018.png)

![image.png](image%2019.png)

---

### **3. Giao tiếp 1 số ngoại vi cơ bản (giao tiếp rời)**

1. **Mô phỏng Wokwi (ESP32)**
2. **Các module: Led - button, DHT11/22, Oled, Buzzer tần số, DS1307 (EEPROM)**

[Wokwi](Wokwi%201fb93a1556df805080f4f5b3160ee423.csv)

---

### **4. Build Project cơ bản (Mỗi ý là 1 task/softTimer)**

---

- **Yêu cầu**
    - 1 loại cảm biến(No outputDigital)(1 task) (lưu vào biến toàn cục): **DHT 11**
    - LCD hiển thị 2 giá trị cảm biến(tùy chọn) (SoftTimer 1s/lần): **Hiển thị nhiệt độ + độ ẩm**
    - 1 task chạy buzzer tần số (thụ động): **Chạy bài nhạc Happy Birthday**
    - 2 btn bật/tắt 1 led(1 task cần đáp ứng liền)
    - 1 task chạy 1 btn cấp Semaphore (max 5 lần) (semaphoreGive()=up())
    - 1 task để chớp tắt 1 led (chớp tắt 3 lần, T=1s), được cấp Semaphore. (SemaphoreTake() = down())
- **Setup Demo**
    - Bước 1: Tạo Project mới trong VSCode
        1. Mở **VSCode**
        2. Vào mục **Extensions** và **cài đặt PlatformIO IDE**
        
        ![Picture12.png](Picture12.png)
        
        1. Sau khi cài đặt xong, click vào biểu tượng **PlatformIO** ở thanh bên trái
            
            ![13.png](13.png)
            
        2. Chọn **"New Project"**
        3. Trong cửa sổ tạo project:
            - Đặt tên project
            - Chọn board phù hợp (ví dụ: `esp32doit-devkit-v1`)
            - **Chọn framework: `ESP-IDF`**
            - Chọn nơi lưu project
            - Click **Finish**
                
                ![14.png](14.png)
                
        
        ⇒ Sau khi tạo, PlatformIO sẽ tự động tạo cấu trúc thư mục project.
        
    
    ---
    
    - Bước 2: Cách sử dụng menuconfig
        - Cách 1: Vào trực tiếp thông qua Terminal (không tùy chỉnh được nhiều thông số)
            
            ### Bước 1: Cài đặt PlatformIO bằng `pip`
            
            ```bash
            pip install platformio
            
            ```
            
            ---
            
            ### Bước 2: Mở `menuconfig` của ESP-IDF
            
            Tại thư mục gốc project vào trong terminal, chạy:
            
            ```bash
            pio run -t menuconfig
            ```
            
            🧭 Một cửa sổ **menu cấu hình ESP-IDF** sẽ hiện lên với giao diện điều hướng bằng bàn phím:
            
            - Dùng phím **mũi tên** để điều hướng
            - **Enter** để chọn
            - **Q** hoặc **ESC** để thoát
            
            ![image.png](image%2013.png)
            
            ---
            
            ### Bước 3: Vào menuconfig dùng các phím mũi tên để di chuyển, Enter để chọn.
            
            ![image.png](image%2014.png)
            
            ![image.png](image%2015.png)
            
            ![image.png](image%2016.png)
            
            ---
            
        - Cách 2: Sử dụng qua thư viện FreeRTOSConfig.h
            
            > ❗ Không chỉnh trực tiếp file gốc của PlatformIO! ( vì nếu chỉnh trục tiếp trong đây sẽ bị ảnh hưởng đến tất cả các file khác nếu như dùng đến FreeRTOS) ⇒ Dùng gián tiếp
            > 
            1. **Tìm file gốc `FreeRTOSConfig.h`** tại đường dẫn:
            
            ```
            C:\Users\<TENNGUOIDUNG>\.platformio\packages\framework-espidf\components\freertos\config\include\freertos
            ```
            
            1. **Copy** file `FreeRTOSConfig.h` vào thư mục `include/` của project bạn mới tạo.
            2. Có 2 lựa chọn:
                - **(A)** Copy toàn bộ nội dung file gốc để tùy chỉnh
                - **(B)** Tạo 1 file mới với nội dung tối giản như sau:
            
            ```c
            #include_next "freertos/FreeRTOSConfig.h"
            
            // Ghi đè các macro tại đây nếu muốn tùy chỉnh
            #define configUSE_IDLE_HOOK 1
            #define configCHECK_FOR_STACK_OVERFLOW 2
            
            ```
            
            ⇒File này sẽ **kế thừa** toàn bộ nội dung gốc từ ESP-IDF và chỉ ghi đè các macro bạn muốn thay đổi.
            
    
    ---
    
    - Bước 3: Cấu hình `platformio.ini`
        1. Mở file `platformio.ini`
        2. Thêm dòng sau:
        
        ```
        build_flags = -Iinclude
        ```
        
        - Giải thích:
            - `build_flags`: Cho phép thêm các tùy chọn khi biên dịch.
            - `Iinclude`: Thêm thư mục `include/` vào đường dẫn tìm kiếm file header (`.h`).
        1. Cấu hình hoàn chỉnh:
        
        ```
        platform = espressif32
        board = esp32doit-devkit-v1
        framework = espidf
        monitor_speed = 115200
        build_flags = -Iinclude
        ```
        
        ![16.png](16.png)
        
    
    ---
    
- **Sơ đồ kết nối chân**
    
    ![image.png](image%2020.png)
    
- Phân tích FreeRTOS trong Project
    - **Thư viện được include**:
        
        ```c
        #include "freertos/FreeRTOS.h"
        #include "freertos/task.h"
        #include "freertos/semphr.h" // chỉ ở file main.c
        ```
        
    
    ---
    
    - 1. `main.c` – **Điều phối các task và semaphore**
        
        ### a. Tạo các Task với FreeRTOS
        
        ```c
        xTaskCreate(vDisplay, "LCD Task", 2048, NULL, 1, NULL);
        xTaskCreate(music_task, "Music Task", 2048, NULL, 5, NULL);
        xTaskCreate(producer, "Producer Task", 2048, NULL, 1, NULL);
        xTaskCreate(consumer, "Consumer Task", 2048, NULL, 1, NULL);
        xTaskCreate(control_led, "Control LED Task", 2048, NULL, 2, NULL);
        
        ```
        
        **Mỗi `xTaskCreate` tạo một luồng chạy độc lập**, xử lý một nhiệm vụ cụ thể:
        
        - Hiển thị LCD
        - Phát nhạc
        - Ghi nhận nút nhấn và chuyển trạng thái LED
        - Điều khiển LED nhấp nháy
        - Bật/tắt LED tức thời
        
        ---
        
        ### b. Tạo và dùng Semaphore
        
        ```c
        sem_filled = xSemaphoreCreateCounting(BUF_SIZE, 0);
        xSemaphoreGive(sem_filled);
        xSemaphoreTake(sem_filled, portMAX_DELAY);
        
        ```
        
        **Dùng để đồng bộ giữa producer-consumer**: `producer()` sẽ "cấp phép" khi người dùng nhấn nút, còn `consumer()` sẽ dùng phép đó để điều khiển LED.
        
        ---
        
        ### c. Delay Task bằng `vTaskDelay`
        
        ```c
        vTaskDelay(pdMS_TO_TICKS(20));
        
        ```
        
    
    ---
    
    - 2. `dht_display.c` – **Task hiển thị dữ liệu lên LCD**
        
        ```c
        void vDisplay(void* pvParam)
        ```
        
        - Đây là một FreeRTOS Task chạy liên tục trong vòng lặp `while(1)`
        - Dùng `vTaskDelay(2000 / portTICK_PERIOD_MS);` để cập nhật LCD mỗi 2 giây
        
    
    ---
    
    ## 3. `dht11.c` – **Sử dụng `vTaskDelay()` để đợi cảm biến ổn định**
    
    ```c
    void DHT11_init(gpio_num_t gpio_num) {
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
    ```
    
    - Đảm bảo cảm biến DHT11 ổn định sau khi cấp nguồn
    
    ---
    
    ## 4. `lcd_i2c.c` – **Dùng `vTaskDelay()` để delay sau khi gửi lệnh LCD**
    
    Ví dụ:
    
    ```c
    if (data_byte == CLEAR_DISPLAY)
        vTaskDelay(2 / portTICK_PERIOD_MS);
    
    vTaskDelay(50 / portTICK_PERIOD_MS);
    
    ```
    
     Các lệnh delay ở đây để **đảm bảo LCD có đủ thời gian xử lý lệnh** theo đặc tả kỹ thuật của nó
    
    ---
    
    ## 5. `music.c` – **Dùng `vTaskDelay()` để ngắt quãng giai điệu**
    
    ```c
    vTaskDelay(pdMS_TO_TICKS(duration_ms));
    vTaskDelay(pdMS_TO_TICKS(noteDuration * 0.3));
    vTaskDelay(pdMS_TO_TICKS(2000));
    
    ```
    
    - **`music_task()`** là một FreeRTOS Task, chạy nhạc nền bằng cách delay giữa các nố

---

<aside>
🔗

**Link build project:**  

[https://github.com/NHN4464/RTOS](https://github.com/NHN4464/RTOS)

[RTOS - Project cơ bản](https://youtube.com/shorts/HRACDEE-dgk?feature=share)

</aside>

<aside>
🔗

**Link bổ sung (build rời từng task):** 

[https://github.com/NHN4464/RTOS_module](https://github.com/NHN4464/RTOS_module)

</aside>

---

---

### **5. Tìm hiểu các API (hàm/cơ chế) mà FreeRTOS cung cấp**

---

- **1.  Task Management – Quản lý tiến trình**
    
    ---
    
    <aside>
    🔗
    
    **Link mô phỏng:**  
    
    [RTOS---DEMO/task_management at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/task_management)
    
    [vongdoi - Wokwi ESP32, STM32, Arduino Simulator](https://wokwi.com/projects/432727435116581889)
    
    [[FreeRTOS_ESP32]taks_management](https://youtu.be/tI2tyYGdnvc?si=3piXu15nGJavz__z)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            
            // TaskHandle toàn cục
            TaskHandle_t led1_task_handle = NULL;
            
            void led1Task(void *pvParameters) {
                while (1) {
                    printf("LED1 Task: Dang chay...\n");
                    vTaskDelay(pdMS_TO_TICKS(1000)); // Delay 1 giây
                }
            }
            
            void taskMonitor(void *pvParameters) {
             
                while (led1_task_handle == NULL) {
                    vTaskDelay(pdMS_TO_TICKS(100));
                }
            
                printf("TaskMonitor: Dang theo doi LED1 Task...\n");
                while (1) {
                    eTaskState state = eTaskGetState(led1_task_handle);
             
                    printf("TaskMonitor: Trang thai LED1 Task: %d\n", state); 
                    vTaskDelay(pdMS_TO_TICKS(500)); 
                }
            }
            
            void controlTask(void *pvParameters) {
            
                while (led1_task_handle == NULL) {
                    vTaskDelay(pdMS_TO_TICKS(100));
                }
            
                printf("ControlTask: Dang dieu khien LED1 Task...\n");
                while (1) {
                    printf("ControlTask: Tam dung LED1 Task\n");
                    vTaskSuspend(led1_task_handle);
                    vTaskDelay(pdMS_TO_TICKS(3000)); 
            
                    printf("ControlTask: Kich hoat lai LED1 Task\n");
                    vTaskResume(led1_task_handle);
                    eTaskState state = eTaskGetState(led1_task_handle);
                    printf("ControlTask: Trang thai LED1 Task: %d\n", state);
                    vTaskDelay(pdMS_TO_TICKS(3000));
                }
            }
            
            void app_main(void) {
                printf("app_main: Khoi tao cac task...\n");
            
              
                xTaskCreate(led1Task, "LED1Task", 2048, NULL, 4, &led1_task_handle);
            
             
                xTaskCreate(taskMonitor, "TaskMonitor", 4096, NULL, 5, NULL);
            
             
                xTaskCreate(controlTask, "ControlTask", 2048, NULL, 3, NULL);
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2021.png)
            
    
    ---
    
    - **Task management trong FreeRTOS trên ESP32** là cách quản lý các **nhiệm vụ (task)** độc lập chạy song song (gần giống như đa luồng) trong hệ thống nhúng. FreeRTOS cho phép bạn tạo, xóa, tạm dừng, tiếp tục và thay đổi mức độ ưu tiên của các task.
    - **Các hàm API:**
        - **Tạo và Xóa Task:**
            - **`xTaskCreate()`:** Dùng để khởi tạo một task mới, đưa nó vào trạng thái hoạt động ban đầu.
            - **`vTaskDelete():`** Dùng để loại bỏ một task khỏi hệ thống khi nó không còn cần thiết.
        - **Điều khiển thời gian và trạng thái Task:**
            - **`vTaskDelayUntil():`** Tạm dừng task cho đến một thời điểm cụ thể, hữu ích cho các tác vụ định kỳ hoặc cần độ chính xác về thời gian.
            - **`vTaskDelay():`** Tạm dừng task trong một khoảng thời gian cụ thể, cho phép các task khác thực thi.
            - **`vTaskSuspend():`** Tạm dừng hoạt động của một task, đưa nó vào trạng thái không hoạt động cho đến khi được kích hoạt lại.
            - **`vTaskResume():`** Kích hoạt lại một task đã bị tạm dừng, đưa nó trở lại trạng thái sẵn sàng thực thi.
        - **Giám sát và Debug:**
            - **`uxTaskGetStackHighWaterMark()`:** (Debug) Kiểm tra mức sử dụng stack cao nhất của task, hỗ trợ việc debug và tối ưu hóa bộ nhớ.
            - **`eTaskStateGet()`:** Lấy trạng thái hiện tại của một task, giúp theo dõi quá trình thực thi của nó.
    - **Các trạng thái của Task bao gồm:  ready(1) -> running(2) ->blocked(3)**

---

- **2. Time management - Quản lý thời gian**
    
    ---
    
    <aside>
    🔗
    
    Link: 
    
    [RTOS---DEMO/time_management at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/time_management)
    
    [[FreeRTOS_ESP32]time_management](https://youtu.be/cYt4GH3l7wU?si=R38ZQLmai9W1OxpB)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "driver/gpio.h"
            
            #define LED1_GPIO 2
            #define LED2_GPIO 4
            
            TaskHandle_t led2_task_handle = NULL; // Handle cho led2_task
            
            void led_init(void) {
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED1_GPIO) | (1ULL << LED2_GPIO),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            void led1_task(void *pvParameters) {
                TickType_t start_time = xTaskGetTickCount();
                while (1) {
                    gpio_set_level(LED1_GPIO, 1); 
                    vTaskDelay(pdMS_TO_TICKS(1000)); 
                    gpio_set_level(LED1_GPIO, 0); 
                    vTaskDelay(pdMS_TO_TICKS(1000)); 
            
                    // Tính thời gian đã trôi qua
                    TickType_t current_time = xTaskGetTickCount();
                    uint32_t elapsed_ms = (current_time - start_time) * portTICK_PERIOD_MS;
                    printf("LED1 Task: Đã chạy %lu ms\n", elapsed_ms);
                }
            }
            
            void led2_task(void *pvParameters) {
                TickType_t start_time = xTaskGetTickCount(); 
                uint32_t counter = 0;
                while (1) {
                    gpio_set_level(LED2_GPIO, 1); 
                    vTaskDelay(pdMS_TO_TICKS(100)); 
                    gpio_set_level(LED2_GPIO, 0); 
                    vTaskDelay(pdMS_TO_TICKS(100)); 
                    counter += 200;
            
                   
                    TickType_t current_time = xTaskGetTickCount();
                    uint32_t elapsed_ms = (current_time - start_time) * portTICK_PERIOD_MS;
                    printf("LED2 Task: Đã chạy %lu ms, Counter: %lu ms\n", elapsed_ms, counter);
            
                  
                    if (counter == 5000) {
                        printf(">>> Tạm dừng LED2 Task\n");
                        vTaskSuspend(NULL); 
                    }
                }
            }
            
            void monitor_task(void *pvParameters) {
                while (1) {
                    TickType_t current_time = xTaskGetTickCount();
                    uint32_t elapsed_ms = current_time * portTICK_PERIOD_MS;
            
                  
                    if (elapsed_ms >= 10000) {
                        printf(">>> Tiếp tục LED2 Task\n");
                        vTaskResume(led2_task_handle);
                       
                        vTaskDelay(pdMS_TO_TICKS(10000)); 
                    }
                    vTaskDelay(pdMS_TO_TICKS(1000)); 
                }
            }
            
            void app_main(void) {
                led_init();
                xTaskCreate(led1_task, "LED1 Task", 2048, NULL, 1, NULL);
                xTaskCreate(led2_task, "LED2 Task", 2048, NULL, 1, &led2_task_handle);
                xTaskCreate(monitor_task, "Monitor Task", 2048, NULL, 1, NULL);
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2022.png)
            
    
    ---
    
    - **Time management (quản lý thời gian)** trong **FreeRTOS trên ESP32** là quá trình sử dụng các hàm và cơ chế của FreeRTOS để kiểm soát **thời gian thực thi, trễ, hẹn giờ và đồng bộ thời gian** giữa các task.
    - **Các hàm API:**
        - **`vTaskDelay()`:** Chức năng để tạo độ trễ (delay) dạng ngủ (sleep), dựa trên số lượng tick đã đếm được (tick count).
        - **`xTaskGetTickCount()`:** Lấy tổng số tick đã trôi qua kể từ khi hệ thống khởi động.
        - **`xTaskGetTickCountFromISR()`:** Phiên bản của hàm xTaskGetTickCount() dùng trong ngữ cảnh ngắt (ISR).
        - **`portTICK_PERIOD_MS`:** Một hằng số hoặc macro dùng để chuyển đổi giá trị tick sang đơn vị mili-giây.

---

- **3. Semaphore & Mutex - Đồng bộ hóa**
    
    ---
    
    <aside>
    🔗
    
    **Link Binary Semaphore:** 
    
    [RTOS---DEMO/semaphore at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/semaphore)
    
    [[FreeRTOS_ESP32]semaphore binary](https://youtu.be/zOHsQwscARg?si=Tlps5VjAzGD0d_60)
    
    </aside>
    
    - **Demo Binary Semaphore:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "FreeRTOSConfig.h"
            #include "freertos/semphr.h"
            #include "driver/gpio.h"
            
            #define LED_GPIO 2
            
            SemaphoreHandle_t xSemaphore = NULL;
            
            void led_init(void) {
                gpio_config_t io_conf = {
                    .pin_bit_mask = 1ULL << LED_GPIO,
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            void sender_task(void *pvParameters) {
                while (1) {
                    vTaskDelay(pdMS_TO_TICKS(2000)); 
                    xSemaphoreGive(xSemaphore);      
                    printf("Semaphore given\n");
                }
            }
            
            void led_task(void *pvParameters) {
                while (1) {
                    if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
                        gpio_set_level(LED_GPIO, 1); 
                        vTaskDelay(pdMS_TO_TICKS(500));
                        gpio_set_level(LED_GPIO, 0); 
                        vTaskDelay(pdMS_TO_TICKS(500));
                    }
                }
            }
            
            void app_main() {
                led_init();
            
                xSemaphore = xSemaphoreCreateBinary(); 
            
                if (xSemaphore != NULL) {
                    xTaskCreate(sender_task, "SenderTask", 2048, NULL, 0, NULL);
                    xTaskCreate(led_task, "LEDTask", 2048, NULL, 2, NULL);
                } else {
                    printf("Failed to create semaphore\n");
                }
            }
            
            ```
            
        - Kết quả:
            
            ![image.png](image%2023.png)
            
    
    ---
    
    <aside>
    🔗
    
    **Link Couting Semaphore:** 
    
    [RTOS---DEMO/semaphor_count at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/semaphor_count)
    
    [[FreeRTOS_ESP32]semaphore counting](https://youtu.be/yNfe__hzBT0?si=h8PdyblU9-TnhaN_)
    
    </aside>
    
    - **Demo Couting Semaphore:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "FreeRTOSConfig.h"
            #include "freertos/task.h"
            #include "freertos/semphr.h"
            #include "driver/gpio.h"
            
            #define LED_GPIO 2
            
            SemaphoreHandle_t xSemaphore;
            
            void led_init(void) {
                gpio_config_t io_conf = {
                    .pin_bit_mask = 1ULL << LED_GPIO,
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            void signal_task(void *pvParam) {
                while (1) {
                    vTaskDelay(pdMS_TO_TICKS(1000)); 
                    xSemaphoreGive(xSemaphore);
                    printf("Gave signal\n");
                }
            }
            
            void led_task(void *pvParam) {
                while (1) {
                    if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
                        gpio_set_level(LED_GPIO, 1);
                        vTaskDelay(pdMS_TO_TICKS(200));
                        gpio_set_level(LED_GPIO, 0);
                    }
                }
            }
            
            void app_main() {
                led_init();
                xSemaphore = xSemaphoreCreateCounting(1, 0);
            
                if (xSemaphore != NULL) {
                    xTaskCreate(signal_task, "SignalTask", 2048, NULL, 0, NULL);
                    xTaskCreate(led_task, "LEDTask", 2048, NULL, 2, NULL);
                } else {
                    printf("Failed to create semaphore\n");
                }
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2024.png)
            
    
    ---
    
    <aside>
    🔗
    
    **Link Mutex:** 
    
    [[FreeRTOS_ESP32] mutex](https://youtu.be/99GBOr-BBms?si=lYvEJJCM7hGhN-z2)
    
    [RTOS---DEMO/mutex at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/mutex)
    
    </aside>
    
    - **Demo Mutex:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "freertos/semphr.h"
            #include "driver/gpio.h"
            #include "FreeRTOSConfig.h"
            #define LED_GPIO 2
            
            SemaphoreHandle_t xMutex;
            
            void led_init() {
                gpio_config_t io_conf = {
                    .pin_bit_mask = 1ULL << LED_GPIO,
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            void led_blink_task(void *param) {
                const char *taskName = (const char *)param;
                while (1) {
                    if (xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE) {
                        printf("%s: lấy được mutex, bật LED\n", taskName);
                        gpio_set_level(LED_GPIO, 1);
                        vTaskDelay(pdMS_TO_TICKS(500));
                        gpio_set_level(LED_GPIO, 0);
                        printf("%s: tắt LED, trả mutex\n", taskName);
                        xSemaphoreGive(xMutex);
                        vTaskDelay(pdMS_TO_TICKS(500));
                    }
                }
            }
            
            void app_main() {
                led_init();
                xMutex = xSemaphoreCreateMutex();
                
                if (xMutex != NULL) {
                    xTaskCreate(led_blink_task, "Task1", 2048, "Task1", 1, NULL);
                    xTaskCreate(led_blink_task, "Task2", 2048, "Task2", 2, NULL);
                } else {
                    printf("Không thể tạo mutex!\n");
                }
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2025.png)
            
    
    ---
    
    - Trong **FreeRTOS trên ESP32**, **Semaphore** và **Mutex** là hai cơ chế **đồng bộ hóa (synchronization)** cực kỳ quan trọng, được dùng để:
        - Tránh **xung đột truy cập tài nguyên chung** (ví dụ: UART, cảm biến, LCD).
        - Đồng bộ giữa các **task**, hoặc giữa **ISR và task**.
        - **Giới hạn số lượng task** truy cập vào vùng tài nguyên giới hạn
    - **Các hàm API:**
        - **`xSemaphoreCreateBinary()`:** Tạo binary semaphore.
        - **`xSemaphoreCreateCounting()`:** Tạo counting semaphore.
        - **`xSemaphoreGive()`**: Giải phóng semaphore.
        - **`xSemaphoreTake()`:** Lấy semaphore.
        - **`xSemaphoreGiveFromISR()`:** Dùng để giải phóng semaphore từ ngữ cảnh ngắt (ISR).
        - **`xSemaphoreTakeFromISR()`:** Dùng để lấy semaphore từ ngữ cảnh ngắt (ISR).
        - **`xSemaphoreCreateMutex()`:** Tạo mutex.
        - **`xSemaphoreCreateRecursiveMutex()`:** Tạo mutex lồng nhau.

---

- **4. Queue - Hàng đợi giao tiếp**
    
    ---
    
    <aside>
    🔗
    
    Link: 
    
    [RTOS---DEMO/queue at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/queue)
    
    [[FreeRTOS] queue](https://youtu.be/gnCUmLBMu5c?si=7C49ojfhQC2329VK)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "freertos/queue.h"
            #include "driver/gpio.h"
            #include "FreeRTOSConfig.h"
            #define LED_GPIO    2 
            
            QueueHandle_t xQueue;
            
            // Khởi tạo LED output
            void led_init(void) {
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED_GPIO),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            // Task gửi tín hiệu vào queue
            void sender_task(void *pvParameters) {
                int signal = 1;
                while (1) {
                   if( xQueueSend(xQueue, &signal, portMAX_DELAY)==pdPASS){
                    printf("send data: %d - Free:%d \n",signal,uxQueueSpacesAvailable(xQueue));
                    signal++;
                   }
                   else{ printf("fail to send\n");}
                   printf("task 1 do something \n");
                }
            }
            
            // Task nhận tín hiệu và bật LED
            void receiver_task(void *pvParameters) {
                int recv=0;
                while (1) {
                    if (xQueueReceive(xQueue, &recv, pdMS_TO_TICKS(500)) == pdTRUE) {
                        gpio_set_level(LED_GPIO, 1);
                        printf("recevie: %d -free:%d \n",recv,uxQueueSpacesAvailable(xQueue)); 
                        vTaskDelay(pdMS_TO_TICKS(500));
                        gpio_set_level(LED_GPIO, 0);
                        printf("recevie: %d -free:%d \n",recv,uxQueueSpacesAvailable(xQueue));
                        vTaskDelay(pdMS_TO_TICKS(500));
                    }
                    else{
                        printf("fail\n");
                    }
                    printf("task 2 do something \n");
                }
            }
            
            void app_main(void) {
                led_init();
            
                xQueue = xQueueCreate(5, sizeof(int));  
            
                if (xQueue != NULL) {
                    xTaskCreate(sender_task, "SenderTask", 2048, NULL, 5, NULL);
                    xTaskCreate(receiver_task, "ReceiverTask", 2048, NULL, 5, NULL);
                } else {
                    printf("Không tạo được hàng đợi!\n");
                }
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2026.png)
            
    
    ---
    
    - **Queue (hàng đợi)** là một cơ chế **giao tiếp giữa các task** hoặc giữa **ISR và task**, cực kỳ hiệu quả và an toàn. Queue cho phép các task **gửi và nhận dữ liệu (message passing)** theo kiểu FIFO (First-In-First-Out).
    - **Các hàm API:**
        - `xQueueCreate()`: Tạo hàng đợi.
        - `xQueueSend()` / `xQueueSendToBack()`: Gửi dữ liệu vào queue.
        - `xQueueReceive()`: Nhận dữ liệu từ queue.
        - `xQueuePeek()`: Nhìn dữ liệu mà không xóa.
        - `xQueueSendFromISR()` / `xQueueReceiveFromISR()`: Phiên bản dùng trong ISR.

---

- **5. Event Group - Tập hợp tín hiệu (bit flags)**
    
    ---
    
    <aside>
    🔗
    
    Link:  
    
    [[FreeRTOS] eventgroup](https://youtu.be/OfZZ-PxsN4g?si=QYlsFJUWuHsRv2m1)
    
    [event group - Wokwi ESP32, STM32, Arduino Simulator](https://wokwi.com/projects/432817144297583617)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "freertos/event_groups.h"
            #include "driver/gpio.h"
            
            #define BIT_TASK1   (1 << 0)
            #define BIT_TASK2   (1 << 1)
            
            #define LED_GPIO    GPIO_NUM_2
            
            EventGroupHandle_t xEventGroup;
            
            void led_init(void) {
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED_GPIO),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            }
            
            void task1(void *pvParameters) {
                while (1) {
                    printf("Task 1: set BIT_TASK1\n");
                    xEventGroupSetBits(xEventGroup, BIT_TASK1);
                    vTaskDelay(pdMS_TO_TICKS(1000));
                }
            }
            
            void task2(void *pvParameters) {
                while (1) {
                    printf("Task 2: set BIT_TASK2\n");
                    xEventGroupSetBits(xEventGroup, BIT_TASK2);
                    vTaskDelay(pdMS_TO_TICKS(1000));
                }
            }
            
            void task3(void *pvParameters) {
                while (1) {
                    EventBits_t bits = xEventGroupWaitBits(
                        xEventGroup,
                        BIT_TASK1 | BIT_TASK2,
                        pdTRUE,       
                        pdTRUE,       
                        portMAX_DELAY
                    );
            
                    if ((bits & (BIT_TASK1 | BIT_TASK2)) == (BIT_TASK1 | BIT_TASK2)) {
                        printf("Task 3: Nhận đủ bit → BẬT LED\n");
                        gpio_set_level(LED_GPIO, 1);  
                        vTaskDelay(pdMS_TO_TICKS(1000));
                        gpio_set_level(LED_GPIO, 0);  
                    }
                }
            }
            
            void app_main(void) {
                led_init(); 
            
                xEventGroup = xEventGroupCreate();
            
                xTaskCreate(task1, "Task 1", 2048, NULL, 1, NULL);
                xTaskCreate(task2, "Task 2", 2048, NULL, 1, NULL);
                xTaskCreate(task3, "Task 3", 2048, NULL, 2, NULL);
            }
            
            ```
            
        - Kết quả:
            
            ![image.png](image%2027.png)
            
    
    ---
    
    - **Event Group** là một cơ chế đồng bộ dùng để **thiết lập, chờ và kiểm tra nhiều cờ (bit)** trong cùng một nhóm. Nó cực kỳ hữu ích khi cần:
        - **Đồng bộ nhiều điều kiện hoặc tín hiệu** cùng lúc.
        - **Một task chờ nhiều sự kiện** từ các task khác hoặc từ ISR.
        - Giống như "semaphore nhiều bit" – mỗi bit là một sự kiện riêng.
    - Các hàm API:
        - `xEventGroupCreate()`: Tạo event group.
        - `xEventGroupSetBits()`: Set các bit.
        - `xEventGroupClearBits()`: Xóa các bit.
        - `xEventGroupWaitBits()`: Đợi đến khi bit được set.
    - Event Group được dùng như signal flags, hiệu quả hơn queue khi chỉ cần thông báo trạng thái.
    
    | **Tiêu chí** | **Event Group** | **Queue** |
    | --- | --- | --- |
    | Dữ liệu truyền | Chỉ là **bit flag** (tối đa 24 bit) | Dữ liệu thật (struct, biến, ...) |
    | Mục tiêu | Thông báo trạng thái | Truyền thông tin/data |
    | Nhiều task cùng chờ | Có thể đồng bộ nhiều task 1 lúc | Mỗi message cho 1 consumer |
    | Hiệu suất | Rất nhanh, ít tài nguyên | Nặng hơn do dùng bộ nhớ đệm |

---

- **6. Task Notification - Cơ chế signal siêu nhẹ**
    
    ---
    
    <aside>
    🔗
    
    **Link**:  
    
    [RTOS---DEMO/task_nofication at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/task_nofication)
    
    [Task Notification  - Wokwi ESP32, STM32, Arduino Simulator](https://wokwi.com/projects/432731937535790081)
    
    [[FreeRTOS] task nofication](https://youtu.be/Qt90gRTUIno?si=QzCQoaJuLvHSCMhN)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "driver/gpio.h"
            
            #define LED_PIN GPIO_NUM_2
            
            TaskHandle_t task_led_handle = NULL;
            
            void task_led_receiver(void *pvParameters) {
                while (1) {
            
                    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
            
                    
                    gpio_set_level(LED_PIN, 1);
                    printf("notify has been receviced \n");
                    vTaskDelay(pdMS_TO_TICKS(500));  
                    gpio_set_level(LED_PIN, 0);
                }
            }
            
            void task_giver(void *pvParameters) {
                while (1) {
                    vTaskDelay(pdMS_TO_TICKS(1000));
                    xTaskNotifyGive(task_led_handle); 
                    printf("notify has been sent \n");
                    vTaskDelay(pdMS_TO_TICKS(1000)); 
                }
            }
            
            void app_main(void) {
             
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED_PIN),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE,
                };
                gpio_config(&io_conf);
            
               
                xTaskCreate(task_led_receiver, "task_led", 2048, NULL, 2, &task_led_handle);
            
                xTaskCreate(task_giver, "task_giver", 2048, NULL, 1, NULL);
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2028.png)
            
    
    ---
    
    - **Task Notification** là một **cơ chế đồng bộ hóa và giao tiếp cực kỳ nhẹ, nhanh và hiệu quả**, được dùng thay thế cho **Semaphore**, **Queue** hoặc **Event Group** trong nhiều trường hợp.
    - Mỗi task trong FreeRTOS có **mặc định 1 vùng thông báo riêng (32-bit)**.
    - Cơ chế này cho phép task nhận:
        - **Tín hiệu (giống Binary Semaphore)**
        - **Dữ liệu (giống Queue nhỏ)**
        - **Cờ bit (giống Event Group)**
    - **Các hàm API:**
        - `xTaskNotify()`: Gửi thông báo đến task.
        - `xTaskNotifyWait()`: Task đợi thông báo.
        - `xTaskNotifyGive()` / `ulTaskNotifyTake()`: Phiên bản "give/take" như semaphore.
    
    | **Semaphore** | **Task Notification** |
    | --- | --- |
    | Cần tạo semaphore | Không cần tạo gì thêm (sẵn trong mỗi task) |
    | Tốn RAM nhiều hơn | Rất nhẹ, dùng nội bộ TCB |
    | API phức tạp hơn | API đơn giản hơn, dùng cho 1 task |
    | Có thể chia sẻ nhiều task | Thường dùng 1:1 giữa 2 task |

---

- **7. Timer - Bộ định thời phần mềm**
    
    ---
    
    <aside>
    🔗
    
    **Link**: 
    
    [RTOS---DEMO/timer at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/timer)
    
    [[FreeRTOS] Timer(Soft time)](https://youtu.be/hBIvKRd2InU?si=OIJK02Ck7TFCTCVS)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/task.h"
            #include "freertos/timers.h"
            #include "driver/gpio.h"
            
            #define LED_PIN GPIO_NUM_2
            
            TimerHandle_t led_timer_handle = NULL;
            
            bool led_state = false;
            
            void led_timer_callback(TimerHandle_t xTimer) {
            
                led_state = !led_state;
                gpio_set_level(LED_PIN, led_state);
                printf("Timer callback: LED %s\n", led_state ? "ON" : "OFF");
            }
            
            void app_main(void) {
            
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED_PIN),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE,
                };
                gpio_config(&io_conf);
                
                led_timer_handle = xTimerCreate("LED Timer",pdMS_TO_TICKS(1000),pdTRUE,(void *)0,led_timer_callback);
            
                if (led_timer_handle != NULL) {
                    xTimerStart(led_timer_handle, 0);
                } else {
                    printf("Failed to create timer!\n");
                }
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2029.png)
            
    
    ---
    
    - **Timer (Soft Timer)** là một **timer phần mềm**, chạy trên nền của **task quản lý timer**. Nó cho phép bạn **tự động gọi hàm (callback)** sau một khoảng thời gian nhất định, **một lần hoặc lặp lại** – mà không cần bạn phải tạo thêm task riêng.
    - **Ưu điểm của Soft Timer (so với task riêng)**
    
    | Tiêu chí | Dùng Task riêng | Dùng Timer |
    | --- | --- | --- |
    | Tốn RAM | Tốn stack/task RAM | Không cần thêm task |
    | Lặp định kỳ | Cần delay loop | Có sẵn chu kỳ |
    | Quản lý thời gian | Cần viết thêm logic | Có sẵn hàm quản lý |
    | Độ chính xác | Cao (tùy cấu hình) | Cao (ms-level) |
    - **Các hàm API:**
        - `xTimerCreate()`: Tạo phần mềm timer.
        - `xTimerStart()` / `xTimerStop()`: Bắt đầu / dừng timer.
        - `xTimerChangePeriod()`: Đổi chu kỳ.
        - `xTimerCallbackFunction`: Hàm gọi khi timer hết hạn.
    
    ⇒ Rất hữu ích để xử lý timeout, polling, hoặc thực thi định kỳ không dùng task.
    

---

- **8. Memory Management – Cấp phát bộ nhớ**
    
    ---
    
    <aside>
    🔗
    
    **Link:** 
    
    [RTOS---DEMO/memmory at main · NHN4464/RTOS---DEMO](https://github.com/NHN4464/RTOS---DEMO/tree/main/memmory)
    
    [[FreeRTOS] Memory_management](https://youtu.be/GabFGBv08y4?si=s4cIfS512c9FAz1m)
    
    </aside>
    
    - **Demo:**
        - Code demo:
            
            ```c
            #include <stdio.h>
            #include <string.h>
            #include "freertos/FreeRTOS.h"
            #include "freertos/timers.h"
            #include "driver/gpio.h"
            #include "esp_log.h"
            #include "freertos/semphr.h"
            
            #define LED_GPIO GPIO_NUM_2
            static const char *TAG = "LED_MALLOC";
            
            typedef struct {
                gpio_num_t gpio;
                bool state;
            } led_control_t;
            
            // Hàm callback timer
            void led_timer_callback(TimerHandle_t xTimer) {
                led_control_t *led = (led_control_t *) pvTimerGetTimerID(xTimer);
                if (led == NULL) return;
            
                led->state = !led->state;
                gpio_set_level(led->gpio, led->state);
                ESP_LOGI(TAG, "LED %s", led->state ? "ON" : "OFF");
            }
            
            void app_main(void) {
             
                gpio_config_t io_conf = {
                    .pin_bit_mask = (1ULL << LED_GPIO),
                    .mode = GPIO_MODE_OUTPUT,
                    .pull_up_en = 0,
                    .pull_down_en = 0,
                    .intr_type = GPIO_INTR_DISABLE
                };
                gpio_config(&io_conf);
            
                led_control_t *led = (led_control_t *) pvPortMalloc(sizeof(led_control_t));
                ESP_LOGI(TAG, "Kích thước led_control_t: %d", sizeof(led_control_t));
            
                if (led == NULL) {
                    ESP_LOGE(TAG, "Không thể cấp phát bộ nhớ cho LED");
                    return;
                }
                led->gpio = LED_GPIO;
                led->state = false;
            
                TimerHandle_t led_timer = xTimerCreate(
                    "led_timer",
                    pdMS_TO_TICKS(1000),  
                    pdTRUE,               
                    (void *) led,         
                    led_timer_callback
                );
            
                if (led_timer == NULL) {
                    ESP_LOGE(TAG, "Tạo timer thất bại");
                    vPortFree(led);
                    return;
                }
            
                xTimerStart(led_timer, 0);
                while (1) {
                    vTaskDelay(pdMS_TO_TICKS(1000));
                }
            }
            ```
            
        - Kết quả:
            
            ![image.png](image%2030.png)
            
    
    ---
    
    - **Trong FreeRTOS, quản lý bộ nhớ (Memory Management) là cách hệ điều hành cấp phát (allocate) và giải phóng (free) bộ nhớ RAM cho:**
        - Stack của task.
        - Queue, Semaphore, Timer.
        - Các cấu trúc nội bộ của hệ thống.
    - **Các hàm API:**
        - **`pvPortMalloc**()`: Cấp phát bộ nhớ.
        - **`vPortFree**():` Giải phóng bộ nhớ.
        - **`heap_1.c – heap_5.c`**: Các chiến lược quản lý bộ nhớ khác nhau (malloc đơn giản, best-fit, coalescing, static,...).
    - FreeRTOS cung cấp **5 lựa chọn** cho heap (qua file `heap_1.c` đến `heap_5.c`).
    - ESP-IDF trong platform IO **mặc định dùng `heap_4.c`** vì nó **tối ưu và linh hoạt nhất**.
    
    | Tên | Đặc điểm chính | Ưu điểm | Nhược điểm |
    | --- | --- | --- | --- |
    | **heap_1** | Không hỗ trợ `free` | Gọn nhẹ | Không dùng được khi cần `free` |
    | **heap_2** | Có `free` đơn giản | Nhẹ | Hay bị phân mảnh |
    | **heap_3** | Dùng malloc/free của C | Dễ tích hợp | Không kiểm soát heap riêng |
    | **heap_4**  | Có `malloc/free` và **chống phân mảnh tốt** | Tốt nhất cho hệ thống phức tạp | Tốn RAM cho metadata |
    | **heap_5** | Hỗ trợ **nhiều vùng heap rời rạc** | Cho hệ thống RAM phân mảnh | Phức tạp |
    
    **⇒ ESP-IDF trong platform IO không sử dụng trực tiếp heap_1.c đến heap_5.c như FreeRTOS gốc**, mà nó có **hệ thống quản lý bộ nhớ riêng**, mạnh mẽ hơn và **tùy chỉnh cho kiến trúc ESP32**. 
    

---

### **~~6. Build 1 Project lớn~~**

- ~~Dùng càng nhiều hàm/cơ chế mà FreeRTOS cung cấp = điểm càng tốt.~~
- ~~Thể hiện tính hợp lý khi viết ứng dụng.~~

<aside>
🔗

**Link:** 

[https://github.com/NHN4464/RTOS_Project_Snake](https://github.com/NHN4464/RTOS_Project_Snake)

[RTOS - Snake game](https://youtube.com/shorts/h6KmTneUNk8?si=VwY7z_8RGs5UjhEm)

[esp32 oled snake - Wokwi ESP32, STM32, Arduino Simulator](https://wokwi.com/projects/432755563248862209)

</aside>

---

- **1. Giới thiệu chương trình**
    - Chương trình này xây dựng một trò chơi **"Snake Game"** chạy trên **ESP32** kết hợp với màn hình **OLED SH1106** thông qua giao tiếp **I2C**. Để quản lý đa luồng, chương trình sử dụng hệ điều hành **FreeRTOS** nhằm xử lý song song các chức năng chính như:
        - Đọc nút nhấn điều khiển từ người dùng.
        - Xử lý logic di chuyển của rắn.
        - Cập nhật và hiển thị hình ảnh lên màn hình OLED.
        - Sơ đồ kết nối
        
        ![image.png](image%2031.png)
        

---

- **2. Các tác vụ sử dụng trong FreeRTOS**
    - Các task được khởi tạo trong hàm `setup()` bằng hàm `xTaskCreate()`:
    
    ```cpp
    xTaskCreate(keyDown, "keyDown", 1024, NULL, 1, &keyDownHandle);
    xTaskCreate(logic, "logic", 2048, NULL, 1, NULL);
    xTaskCreate(draw, "draw", 2048, NULL, 1, NULL);
    ```
    
    | Tên Task | Kích thước Stack | Ưu tiên | Handle | Mô tả |
    | --- | --- | --- | --- | --- |
    | `keyDown` | 1024 byte | 1 | `keyDownHandle` | Đọc trạng thái nút nhấn từ các chân GPIO |
    | `logic` | 2048 byte | 1 | NULL | Cập nhật trạng thái game (rắn, đuôi, điểm, mồi, va chạm) |
    | `draw` | 2048 byte | 1 | NULL | Vẽ đồ họa rắn, viền, điểm, và màn hình kết thúc lên OLED |
    
    > Các task này được thực thi song song nhưng có đồng bộ thông qua semaphore để tránh xung đột dữ liệu.
    > 

---

- **3. Đồng bộ hóa bằng Semaphore**
    - **3.1. Tạo semaphore**
        
        ```cpp
        xSemaphore1 = xSemaphoreCreateBinary();
        xSemaphore2 = xSemaphoreCreateBinary();
        ```
        
        - Hai semaphore kiểu **binary** được tạo ra để **đồng bộ hóa luồng thực thi** giữa `logic` và `draw`.
    - **3.2. Vai trò của semaphore**
        
        
        | Tên Semaphore | Được cấp phát ở task nào | Được chờ ở task nào | Chức năng |
        | --- | --- | --- | --- |
        | `xSemaphore1` | `draw` | `logic` | Cho phép logic thực hiện sau khi vẽ xong |
        | `xSemaphore2` | `logic` | `draw` | Cho phép vẽ sau khi đã xử lý logic xong |
        - **Mô hình hoạt động luân phiên** (ping-pong):
            1. `xSemaphore1` được cấp đầu tiên → `logic` bắt đầu thực hiện.
            2. Sau khi`logic` xử lý xong → `xSemaphore2` được cấp.
            3. Sau khi `draw` vẽ xong → cấp lại `xSemaphore1`.
            4. Quay lại bước 1.
    - **3.3. Cách sử dụng**
        
        ```cpp
        // Trong logic
        if (xSemaphoreTake(xSemaphore1, 0) == pdTRUE) {
          // xử lý game logic
          xSemaphoreGive(xSemaphore2); // cho phép vẽ
        }
        
        // Trong draw
        if (xSemaphoreTake(xSemaphore2, 0) == pdTRUE) {
          // vẽ lên màn hình
          xSemaphoreGive(xSemaphore1); // cho phép logic tiếp tục
        }
        ```
        
        > Cơ chế này đảm bảo luôn luôn vẽ sau khi logic xử lý, tránh rắn chạy loạn  hoặc lỗi hiển thị do sai lệch trạng thái.
        > 

---

- **4. Delay không chặn bằng `vTaskDelay()`**
    
    ### **Ý nghĩa**
    
    Sử dụng `vTaskDelay()` giúp một task **tạm dừng thực thi** mà không block CPU hoặc các task khác. Đây là điểm khác biệt cơ bản so với `delay()` của Arduino.
    
    ### **Ví dụ sử dụng**
    
    ```cpp
    vTaskDelay(pdMS_TO_TICKS(50));  // trong task keyDown
    vTaskDelay(pdMS_TO_TICKS(300)); // trong task draw
    ```
    
    ### **Ứng dụng**
    
    | Vị trí | Thời gian Delay | Mục đích |
    | --- | --- | --- |
    | Trong `keyDown()` | 50ms | Đọc phím định kỳ, tránh lặp vô hạn gây quá tải CPU |
    | Trong `draw()` | 300ms | Làm chậm tốc độ game, tránh rắn chạy quá nhanh |
    | Trong màn hình kết thúc | 100ms | Chờ phím nhấn để chơi lại, kiểm tra định kỳ |

---

- **5. Quản lý trạng thái task: `vTaskSuspend()` và `vTaskResume()`**
    
    ### **Mô tả**
    
    Khi trò chơi kết thúc (thắng hoặc thua), task đọc phím (`keyDown`) sẽ bị **tạm dừng (suspend)** để ngăn người chơi tiếp tục điều khiển. Sau khi nhấn phím bất kỳ, task này được **tiếp tục (resume)** trở lại.
    
    ### **Code minh họa**
    
    ```cpp
    vTaskSuspend(keyDownHandle); // khi game kết thúc
    // ... chờ phím nhấn ...
    vTaskResume(keyDownHandle);  // chơi lại
    ```
    
    ### **Ứng dụng**
    
    - Ngăn rắn bị điều khiển ngoài ý muốn khi chưa khởi động lại
    - Đảm bảo không gây lỗi race condition giữa lần chơi cũ và lần chơi mới

---

- **6. Tổng hợp các API FreeRTOS đã sử dụng**
    
    
    | API | Vai trò | Ghi chú |
    | --- | --- | --- |
    | `xTaskCreate()` | Tạo các task chính | Tạo 3 task: keyDown, logic, draw |
    | `vTaskDelay()` | Delay không chặn CPU | Giúp chạy ổn định, mượt |
    | `xSemaphoreCreateBinary()` | Tạo semaphore nhị phân | Dùng đồng bộ logic ↔ draw |
    | `xSemaphoreTake()` | Chờ semaphore | Đảm bảo task chỉ thực thi khi tới lượt |
    | `xSemaphoreGive()` | Giải phóng semaphore | Cho phép task khác thực thi |
    | `vTaskSuspend()` | Dừng một task | Dừng `keyDown` khi kết thúc game |
    | `vTaskResume()` | Tiếp tục task bị dừng | Kích hoạt lại để chơi tiếp |

---

- **7. Sơ đồ luồng hoạt động các task (dạng mô tả)**
    
    ```
    ┌────────────┐    xSemaphore1     ┌────────────┐
    │  Task draw │◄───────────────────┤ Task logic │
    └────────────┘   xSemaphore2      └────────────┘
           ▲                                │
           │                                ▼
    ┌─────────────────────────────────────────────┐
    │               Task keyDown                  │
    │ (đọc phím định kỳ, thay đổi biến `dir`)    │
    └─────────────────────────────────────────────┘
    
    ```
    

---

- **8. Kết luận**
    
    Việc sử dụng FreeRTOS giúp chương trình được tổ chức rõ ràng, dễ mở rộng và hiệu quả hơn so với kiểu lập trình tuần tự. Cụ thể:
    
    - **Tăng tính phản hồi**: Mỗi chức năng xử lý trong một luồng riêng biệt
    - **Tránh xung đột dữ liệu**: Đồng bộ logic ↔ vẽ bằng semaphore
    - **Tiết kiệm tài nguyên**: delay không blocking và dừng task linh hoạt
    - **Dễ bảo trì và mở rộng**: Có thể thêm âm thanh, AI điều khiển, nhiều level mà không phá vỡ kiến trúc tổng thể

---

[3. Tài liệu tham khảo](3%20Ta%CC%80i%20lie%CC%A3%CC%82u%20tham%20kha%CC%89o%201f993a1556df80088a1bf2c8beada8b8.csv)